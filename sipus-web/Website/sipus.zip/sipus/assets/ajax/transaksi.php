<?php
session_start();
require '../../config/connect.php';

$keyword = $_GET["keyword"];
$transaksi = query_transaksi("SELECT * FROM tbtransaksi
WHERE
idbuku LIKE '$keyword%' OR
idanggota LIKE '$keyword%' OR
idtransaksi LIKE '$keyword%' OR
tglpinjam LIKE '%$keyword%' OR
tglkembali LIKE '%$keyword%'");
// var_dump($tbbuku); 
?>

<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">No.</th>
            <th scope="col">ID Transaksi</th>
            <th scope="col">ID Anggota</th>
            <th scope="col">ID Buku</th>
            <th scope="col">Tgl Pinjam</th>
            <th scope="col">Tgl Kembali</th>
            <?php if ($_SESSION["type"] == "US"):?>
            <th scope="col">Opsi</th>
            <?php endif;?>
        </tr>
    </thead>
    <tbody class="slide">
        <?php $i=1;?>
        <?php foreach($transaksi as $trs):?>
        <tr>
            <th scope="row"><?=$i++;?></th>
            <td><?= $trs['idtransaksi'];?></td>
            <td><?= $trs['idanggota'];?></td>
            <td><?= $trs['idbuku'];?></td>
            <td><?= $trs['tglpinjam'];?></td>
            <?php if ( !($trs['tglkembali'] == NULL)):?>
            <?php if( $trs['tglkembali']>$trs['tglpinjam']):?>
            <td class="bg-success text-white"><?= $trs['tglkembali'];?></td>
            <?php else:?>
            <td class="bg-warning text-dark"><?= $trs['tglkembali'];?></td>
            <?php endif;?>
            <?php else:?>
            <td></td>
            <?php endif;?>
            <?php if ($_SESSION["type"] == "US"):?>
            <td>
                <a href="index.php?p=transaksi-edit&id=<?=$trs['idtransaksi']?>" class="badge badge-warning"><i
                        class="fas fa-edit fa-lg"></i></a>
            </td>
            <?php endif;?>
        </tr>
        <?php endforeach;?>
    </tbody>

</table>