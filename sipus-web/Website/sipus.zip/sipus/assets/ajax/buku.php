<?php
session_start();
require '../../config/connect.php';

$keyword = $_GET["keyword"];
$tbbuku = query_buku("SELECT * FROM tbbuku
WHERE
idbuku LIKE '%$keyword%' OR
judulbuku LIKE '%$keyword%' OR
pengarang LIKE '%$keyword%' OR
kategori LIKE '%$keyword%' OR
penerbit LIKE '%$keyword%' OR
statusbuku LIKE '$keyword%'");
// var_dump($tbbuku); 
?>

<table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">No.</th>
        <th scope="col">ID Buku</th>
        <th scope="col">Judul</th>
        <th scope="col">Kategori</th>
        <th scope="col">Pengarang</th>
        <th scope="col">Penerbit</th>
        <th scope="col">Status</th>
        <?php if (isset($_SESSION["login"]) && $_SESSION["type"] == "US"):?>
        <th scope="col">Opsi</th>
        <?php endif;?>
      </tr>
    </thead>
    <tbody class="slide">
      <?php $i=1;$j=1;?>
      <?php foreach($tbbuku as $buku):?>
      <tr>
        <th scope="row"><?=$i++;?></th>
        <td><?= $buku['idbuku'];?></td>
        <td><?= $buku['judulbuku'];?></td>
        <td><?= $buku['kategori'];?></td>
        <td><?= $buku['pengarang'];?></td>
        <td><?= $buku['penerbit'];?></td>
        <td><?= $buku['statusbuku'];?></td>
    
        <?php if (isset($_SESSION["login"]) && $_SESSION["type"] == "US"):?>
        <td>
          <a href="index.php?p=buku-edit&id=<?=$buku['idbuku']?>" class="badge badge-warning"><i
              class="fas fa-edit fa-lg"></i></a>
        </td>
        <?php endif;?>
      </tr>
      <?php endforeach;?>
    </tbody>

</table>