<?php
session_start();
require '../../config/connect.php';
$keyword = $_GET["keyword"];
$anggota = query_anggota("SELECT * FROM tbanggota
WHERE
idanggota LIKE '$keyword%' OR
nama LIKE '%$keyword%' OR
jeniskelamin LIKE '$keyword%' OR
alamat LIKE '%$keyword%' OR
statusanggota LIKE '%$keyword%'"); 
?>
<table class="table">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">No.</th>
                    <th scope="col">Id Anggota</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Jenis Kelamin</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Status</th>
                    <?php if (isset($_SESSION["login"]) &&  $_SESSION["type"] == "US"):?>
                    <th scope="col">Opsi</th>
                    <?php endif;?>
                </tr>
            </thead>
            <tbody class="slide">
                <?php $i=1;?>
                <?php foreach($anggota as $ag):?>
                <tr>
                    <th scope="row"><?=$i++;?></th>
                    <td><?= $ag['idanggota'];?></td>
                    <td><?= $ag['nama'];?></td>
                    <td><?= $ag['jeniskelamin'];?></td>
                    <td><?= $ag['alamat'];?></td>
                    <td><?= $ag['statusanggota'];?></td>
                    <?php if (isset($_SESSION["login"]) && $_SESSION["type"] == "US"):?>
                    <td>
                        <a href="index.php?p=anggota-edit&id=<?=$ag['idanggota']?>" class="badge badge-warning"><i
                                class="fas fa-edit fa-lg"></i>
                        </a>
                    </td>
                    <?php endif;?>
                </tr>
                <?php endforeach;?>
            </tbody>

        </table>