<?php
session_start();
require '../../config/connect.php';
$keyword = $_GET["keyword"];
$anggota = query_anggota("SELECT idanggota, nama FROM tbanggota
WHERE
nama LIKE '%$keyword%' LIMIT 1" );
?>

<?php foreach($anggota as $ag):?>
<span class="form-control" id="target"><?= $ag['idanggota'];?></span>
<span class="form-control"><?= $ag['nama'];?></span>
<?php endforeach;?> 