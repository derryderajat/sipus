<?php
session_start();
require_once "config/connect.php";
if ( !isset($_SESSION["login"])){
    ($_SESSION["type"] = "AG");
}

$today = date("Y-m-d");
$day = date("D")
// var_dump($today);
?>

<!DOCTYPE html>
<html lang="en">
<!-- DON'T CHANGE THIS -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Perpustakaan</title>
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js"
        integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous">
    </script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js"
        integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous">
    </script>
    <style>
        #div1 {
            width: 350px;
            height: 70px;
            padding: 10px;
            border: 1px solid #aaaaaa;
        }

        .greeting {
            background-color: green;
        }
    </style>
</head>
<!-- DON'T CHANGE HEAD -->
<body>
    <div class="wrapper">
        <!-- Sidebar Menu -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Sistem Informasi Perpustakaan</h3>
            </div>

            <!-- Side Menu: 
                - Display user
                - Data User
                - Data Anggota
                - Data Buku
                - Transaksi Peminjaman
                - About
                - Contact
            -->
            <ul class="list-unstyled components">

                <!-- Display user , NULL if not login-->
                <li style="margin: 0;">
                        <?php if ( isset($_SESSION["login"])):?>
                            <p>
                        <i class="fas fa-user"></i>
                        <?= $_SESSION["user"]?>
                            </p>
                        <?php endif;?>
                        <hr>
                </li>
                <!-- 
                Dashboard menu, Contain:
                    - Chart 
                -->
                <li>
                    <a href="index.php">
                        <i class="fas fa-chart-bar"></i> Dashboard</a>
                </li>
                <!-- Entry data: 
                If logged in will display: Data User, Data Anggota, Data Buku, Transaksi Peminjaman
                If not logged in will display: Data Buku -->
                <li>
                    <!-- Icon Database -->
                    <a href="#Entrydata" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fa fa-database"></i> Entry Data
                    </a>
                    <!-- Menu in Entry data: Description in line 77-79 -->
                    <ul class="collapse list-unstyled" id="Entrydata">
                        <!-- IF login type user, these menus will displayed -->
                        <!-- NOTE: add Admin user, So there is a difference between USER and ADMIN -->
                        <?php if ( isset($_SESSION["login"]) && 
                                   $_SESSION["type"] == "US"):?>
                        <!-- ------------------------------------------------------------ -->
                        <!-- DISPLAYING DATA USERS
                            CONTAINS: 
                                - ID USER 
                                - NAMA
                                - EMAIL
                            GET PAGE FROM : pages/users.php
                        -->
                        <!-- ------------------------------------------------------------ -->
                        <li>
                            <a href="index.php?p=users"><i class="fas fa-users"></i> Data User
                            </a>
                        </li>
                        <!-- ------------------- END GET USERS -------------------------- -->

                        <!-- ------------------------------------------------------------ -->
                        <!-- DISPLAYING DATA ANGGOTA
                            CONTAINS: 
                                - Id Anggota	
                                - Nama	
                                - Jenis Kelamin	
                                - Alamat	
                                - Status	
                                - Opsi {Update dan Hapus Data}
                                - Tambah Anggota
                            GET PAGE FROM : pages/anggota.php
                        -->
                        <li>
                            <a href="index.php?p=anggota"><i class="fas fa-user-friends"></i> Data Anggota</a>
                        </li>
                        <!-- ------------------- END GET ANGGOTA -------------------------- -->
                        <?php endif;?>
                        <!-- ------------------- END CONDITION IF LOGGED IN --------------- -->

                        <!-- ------------------------------------------------------------ -->
                        <!-- DISPLAYING DATA BUKU
                            CONTAINS: 
                                - ID Buku	
                                - Judul
                                - Kategori
                                - Pengarang	
                                - Penerbit	
                                - Opsi {Update dan Hapus Data}
                                - Tambah Buku
                            GET PAGE FROM : pages/buku.php
                        -->
                        <li>
                            <a href="index.php?p=buku"><i class="fas fa-book"></i> Data Buku</a>
                        </li>
                        <!-- ------------------- END GET BUKU -------------------------- -->
                        
                        <!-- IF logged in with USER type this menu will displayed -->
                        <?php if ( isset($_SESSION["login"]) && 
                                   $_SESSION["type"] == "US"):?>
                        <!-- ------------------------------------------------------------ -->
                        <!-- DISPLAYING TRANSAKSI PEMINJAMAN
                            CONTAINS: 
                                - ID Transaksi
                                - ID Anggota
                                - ID Buku
                                - Tgl Pinjam
                                - Tgl Kembali
                                - Opsi {Update dan Hapus Transaksi}
                                - Tambah Buku
                            GET PAGE FROM : pages/transaksi.php
                        -->
                        <li>
                            <a href="index.php?p=transaksi"><i class="fas fa-pen-square"></i> Transaksi Peminjaman</a>
                        </li>
                        <!-- ------------------- END GET TRANSAKSI PEMINJAMAN------------- -->
                        <?php endif;?>
                    </ul>
                </li>
                <!-- MENU ABOUT -->
                <li>
                    <a href="index.php?p=about"><i class="fas fa-question-circle"></i> About</a>
                </li>

                <!-- MENU CONTACT -->
                <li>
                    <a href="index.php?p=contact"><i class="fas fa-paper-plane"></i> Contact</a>
                </li>

            </ul>
        </nav>
        <!-- END SIDE MENU -->
        
        <!-- Page Content  -->
        <div id="content">
            <!-- DATE DAY -->
            <div class="container"><?= $today;?> <?=$day;?></div>
            <!-- TOGGLE HIDE SIDE MENU -->
            <nav class="container navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn toggle">
                        <i class="fas fa-align-left"></i>
                        <span>Toggle Sidebar</span>
                    </button>
                    <div>
                        <?php if ( isset($_SESSION["login"])):?>
                        <a class="btn btn-danger" href="<?=BASEURL;?>/pages/logout.php">
                            Logout
                        </a>
                        <?php else:?>
                        <a class="btn btn-outline-success" href="<?=BASEURL;?>/pages/signin.php">
                            Sign In
                        </a>
                        <?php endif;?>
                    </div>

                </div>
            
            </nav>
            <!-- END TOGGLE SIDE MENU -->

            <!-- TABEL CONTENT -->
            
            <?php

            $pages_dir='pages';  // Destinasi Direktori
            if(!empty($_GET['p'])){  // get untuk p
                $pages=scandir($pages_dir,0); // scan directory alphabetical ascending order
                //array (size=15)
                    // 0 => string '.' (length=1)
                    // 1 => string '..' (length=2)
                    // 2 => string '.htaccess' (length=9)
                    // 3 => string 'anggota-edit.php' (length=16)
                    // 4 => string 'anggota.php' (length=11)
                    // 5 => string 'beranda.php' (length=11)
                    // 6 => string 'buku-edit.php' (length=13)
                    // 7 => string 'buku.php' (length=8)
                    // 8 => string 'contact.php' (length=11)
                    // 9 => string 'logout.php' (length=10)
                    // 10 => string 'signin.php' (length=10)
                    // 11 => string 'tambah-transaksi.php' (length=20)
                    // 12 => string 'transaksi-edit.php' (length=18)
                    // 13 => string 'transaksi.php' (length=13)
                    // 14 => string 'users.php' (length=9)
                unset($pages[0],$pages[1]); // reset variabel pages => Null
                $p=$_GET['p']; // get variabel p assign in p
                if(in_array($p.'.php',$pages)){ 
                    // jika tersedia didalam array
                    // pages/p?=nama_page.php tersedia di $pages
                    //tabel content berubah sesusai $p
                    include ($pages_dir.'/'.$p.'.php');
                }else{
                    // Jika didalam $p tidak ada di direktori maka
                    // diberikan notice "Halaman Tidak Ditemukan"
                    echo'Halaman Tidak Ditemukan';
                }
            }else{
                // Jika tidak ada p?= dikembalikan ke beranda
                include ($pages_dir.'/beranda.php');
            }
            ?>
            <!-- End Tabel -->
            <!-- End Content -->
        </div>
    </div>


    <!-- Don't Change from this line -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="assets/js/bootstrap.js"></script>
    <!-- jQuery Custom Scroller CDN -->
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js">
    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });

            $('#sidebarCollapse').on('click', function () {
                $('#sidebar, #content').toggleClass('active');
                $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });
    </script>
    <!-- chart -->
    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
    <!-- Bootstrap 4 Autocomplete -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-4-autocomplete/dist/bootstrap-4-autocomplete.min.js"
        crossorigin="anonymous"></script>

</body>
</html>