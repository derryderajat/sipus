<?php

define("BASEURL", "http://localhost/sipus");
// SESUAIKAN 
// 1. SERVER
// 2. USER
// 3. PASSWORD
// 4. DATABASE
// ANDA
define("DB_SERVER", 'localhost');
define("DB_USER", 'User ');
define("DB_PASSWORD", 'YourPassword');
define("DB_DATABASE", 'nama Database');
// KONFIGURASI DAHULU DI ATAS

$conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ANGGOTA QUERIES
function query_anggota($query="SELECT * FROM tbanggota ORDER BY idanggota DESC LIMIT 10;"){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ( $row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}
function tambahAnggota($data){
    global $conn;
    // $idbuku = htmlspecialchars($data["idbuku"]);
    $nama = htmlspecialchars($data["nama"]);
    $jeniskelamin = htmlspecialchars($data["jeniskelamin"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $statusanggota = htmlspecialchars($data["statusanggota"]);

    try{
        $checkID = mysqli_query($conn, "SELECT idanggota FROM tbanggota ORDER BY idanggota DESC LIMIT 1");
        $idanggota = mysqli_fetch_assoc($checkID)["idanggota"];
        $tmp = explode("AG",$idanggota);
        $idanggota = (int)end($tmp);
        $idanggota++;
        $idanggota = (string)$idanggota;
        $size = strlen($idanggota);
        while($size<3){
          $idanggota = "0" . $idanggota;
          $size++;
        }
        $idanggota = "AG" . $idanggota;
    }catch(Exception $e){
        echo 'Caught exception: ',  $e->getMessage(), "\n";
    }

    $query = "INSERT INTO tbanggota
    VALUES 
    ('$idanggota', '$nama', '$jeniskelamin','$alamat', '$statusanggota')"; 
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function cariAnggota($keyword, $filter){
    if ($filter == "idanggota"){
        $query = "SELECT * FROM tbanggota 
        WHERE idanggota LIKE '$keyword%'";
    }else if ($filter == "nama"){
        $query = "SELECT * FROM tbanggota 
        WHERE nama LIKE '%$keyword%'";
    }else if ($filter == "alamat"){
        $query = "SELECT * FROM tbanggota 
        WHERE alamat LIKE '%$keyword%'";
    }
    return query_anggota($query);
}

function hapusAnggota($idanggota){
    global $conn;
    mysqli_query($conn, "DELETE FROM tbanggota WHERE idanggota = '$idanggota'");
    return mysqli_affected_rows($conn);
}

function ubahAnggota($data){
    global $conn;
    $idanggota = htmlspecialchars($data["idanggota"]);
    $nama = htmlspecialchars($data["nama"]);
    $jeniskelamin = htmlspecialchars($data["jeniskelamin"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $statusanggota = htmlspecialchars($data["statusanggota"]);
    // query insert data
    $query = "UPDATE tbanggota SET
    idanggota = '$idanggota',
    nama = '$nama',
    jeniskelamin = '$jeniskelamin',
    alamat = '$alamat',
    statusanggota = '$statusanggota'
    WHERE idanggota = '$idanggota'"; 

    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

// BUKU QUERIES
function query_buku($query="SELECT * FROM tbbuku ORDER BY idbuku DESC LIMIT 10"){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ( $row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}

function tambahBuku($data){
    global $conn;
    $idbuku = htmlspecialchars($data["idbuku"]);
    $judulbuku = htmlspecialchars($data["judulbuku"]);
    $kategori = htmlspecialchars($data["kategori"]);
    $pengarang = htmlspecialchars($data["pengarang"]);
    $penerbit = htmlspecialchars($data["penerbit"]);
    $statusbuku = htmlspecialchars("Tersedia");
    // query insert data
    $query = "INSERT INTO tbbuku
    VALUES 
    ('$idbuku', '$judulbuku', '$kategori','$pengarang', '$penerbit', '$statusbuku')"; 
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}


function ubahBuku($data){
    global $conn;
    $idbuku = htmlspecialchars($data["idbuku"]);
    $judulbuku = htmlspecialchars($data["judulbuku"]);
    $kategori = htmlspecialchars($data["kategori"]);
    $pengarang = htmlspecialchars($data["pengarang"]);
    $penerbit = htmlspecialchars($data["penerbit"]);
    $statusbuku = htmlspecialchars($data["statusbuku"]);
    // query insert data
    $query = "UPDATE tbbuku SET
    idbuku = '$idbuku',
    judulbuku = '$judulbuku',
    kategori = '$kategori',
    pengarang = '$pengarang',
    penerbit = '$penerbit',
    statusbuku = '$statusbuku'
    WHERE idbuku = '$idbuku'"; 

    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function hapusBuku($idbuku){
    global $conn;
    mysqli_query($conn, "DELETE FROM tbbuku WHERE idbuku = '$idbuku'");
    return mysqli_affected_rows($conn);
}

function cariBuku($keyword, $filter){
    if ($filter == "idbuku"){
        $query = "SELECT * FROM tbbuku 
        WHERE idbuku LIKE '$keyword%'";
    }else if ($filter == "judulbuku"){
        $query = "SELECT * FROM tbbuku 
        WHERE judulbuku LIKE '%$keyword%'";
    }else if ($filter == "pengarang"){
        $query = "SELECT * FROM tbbuku 
        WHERE pengarang LIKE '%$keyword%'";
    }else if ($filter == "kategori"){
        $query = "SELECT * FROM tbbuku 
        WHERE kategori LIKE '%$keyword%'";
    }else if ($filter == "penerbit"){
        $query = "SELECT * FROM tbbuku 
        WHERE penerbit LIKE '%$keyword%'";
    }
    return query_buku($query);
}

// USER QUERIES
function query_user($query="SELECT * FROM tbuser ORDER BY iduser DESC LIMIT 6"){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ( $row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}

// TRANSAKSI QUERIES
function query_transaksi($query="SELECT * FROM tbtransaksi ORDER BY idtransaksi DESC LIMIT 6"){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ( $row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}

function tambahTransaksi($data){
    global $conn;
    $idbuku = htmlspecialchars($data["idbuku"]);
    $idanggota = htmlspecialchars($data["idanggota"]);
    $tglkembali = htmlspecialchars($data["tglkembali"]);


    $GETID = mysqli_query($conn, "SELECT idtransaksi FROM tbtransaksi
    ORDER BY idtransaksi DESC LIMIT 1");
    $IDTRS = mysqli_fetch_assoc($GETID)["idtransaksi"];
    $tmp = explode("TR",$IDTRS);
    $IDTRS = (int)end($tmp);
    $IDTRS++;
    $IDTRS = (string)$IDTRS;
    $size = strlen($IDTRS);
    while($size<3){
      $IDTRS = "0" . $IDTRS;
      $size++;
    }
    $IDTRS = "TR" . $IDTRS;

    // query insert data
    $query = "INSERT INTO tbtransaksi
    VALUES 
    ('$IDTRS', '$idanggota', '$idbuku', CURDATE(), '$tglkembali')"; 
    mysqli_query($conn, $query);

    // Ubah status Anggota
    $statusanggota = htmlspecialchars("Sedang Meminjam");
    $queryAnggota = "UPDATE tbanggota SET
    statusanggota = '$statusanggota'
    WHERE idanggota = '$idanggota'";
    mysqli_query($conn, $queryAnggota);

    // Ubah status Buku
    $statusbuku = htmlspecialchars("Dipinjam");
    $queryBuku = "UPDATE tbbuku SET
    statusbuku = '$statusbuku'
    WHERE idbuku = '$idbuku'";
    mysqli_query($conn, $queryBuku);

    return mysqli_affected_rows($conn);
}
function perpanjangTransaksi($data){
    global $conn;
    $tglkembali = htmlspecialchars($data["tglkembali"]);
    $idtransaksi = htmlspecialchars($data["idtransaksi"]);
    $query = "UPDATE tbtransaksi SET
    tglkembali = '$tglkembali'
    WHERE idtransaksi = '$idtransaksi'";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

function berhentiTransaksi($data){
    global $conn;
    $idtransaksi = htmlspecialchars($data["idtransaksi"]);
    $idbuku = htmlspecialchars($data["idbuku"]);
    $idanggota = htmlspecialchars($data["idanggota"]);
 
    // query insert data
    $query = "UPDATE tbanggota SET
    tglkembali = 'CURDATE()'
    WHERE idtransaksi = '$idtransaksi'";
    mysqli_query($conn, $query);

    // Ubah status Anggota
    $statusanggota = htmlspecialchars("Tidak Meminjam");
    $queryAnggota = "UPDATE tbanggota SET
    statusanggota = '$statusanggota'
    WHERE idanggota = '$idanggota'";
    mysqli_query($conn, $queryAnggota);

    // Ubah status Buku
    $statusbuku = htmlspecialchars("Tersedia");
    $queryBuku = "UPDATE tbbuku SET
    statusbuku = '$statusbuku'
    WHERE idbuku = '$idbuku'";
    mysqli_query($conn, $queryBuku);

    return mysqli_affected_rows($conn);
}


// REGISTRASI USER
function register($data){
    global $conn;
    // [iduser], [nama], [username, password, password2], email
    // $IDUSER = htmlspecialchars($data["iduser"]);
    $NAMA = htmlspecialchars($data["nama"]);
    $USERNAME = htmlspecialchars($data["username"]);
    $PASSWORD = mysqli_real_escape_string($conn, $data["password"]);
    $PASSWORD2 = mysqli_real_escape_string($conn, $data["password2"]);
    $EMAIL = htmlspecialchars($data["email"]);

    //cek apakah ID sudah ada
    try{
        $GETID = mysqli_query($conn, "SELECT iduser FROM tbuser
        ORDER BY iduser DESC LIMIT 1");
        $IDUSER = mysqli_fetch_assoc($GETID)["iduser"];
        $tmp = explode("US",$IDUSER);
        $IDUSER = (int)end($tmp);
        $IDUSER++;
        $IDUSER = (string)$IDUSER;
        $size = strlen($IDUSER);
        while($size<3){
          $IDUSER = "0" . $IDUSER;
          $size++;
        }
        $IDUSER = "US" . $IDUSER;
    }catch(Exception $e){
        echo 'Caught exception: ',  $e->getMessage(), "\n";
    }
    
    //cek apakah username sudah ada
    $checkUsername = mysqli_query($conn, "SELECT username FROM tbuser
        WHERE username = '$USERNAME'");
        
    // Check ID
    if (mysqli_fetch_assoc($checkUsername)){
        echo "<script>
                alert('Username is already used !');
                </script>";
        return false;
    
    }

    //cek apakah username sudah ada
    $checkEmail = mysqli_query($conn, "SELECT email FROM tbuser
    WHERE email = '$EMAIL'");
        
    // Check ID
    if (mysqli_fetch_assoc($checkEmail)){
        echo "<script>
                alert('Username is already used !');
                </script>";
        return false;
    
    }

    // Cek keseuaian Password
    if ( $PASSWORD !== $PASSWORD2){
        echo "<script>
                alert('Passwords are doesn\'t match');
             </script>";
        
        return false;
    }

    // enkripsi password
    $PASSWORD = password_hash($PASSWORD, PASSWORD_DEFAULT);
    
    // tambahkan userbaru ke db
    mysqli_query($conn, "INSERT INTO tbuser VALUES('$IDUSER', '$NAMA', '$USERNAME', '$PASSWORD', '$EMAIL')");
    return mysqli_affected_rows($conn);
}




// mysql user
$transaksi = query_transaksi();

// mysql user
$users = query_user();

// mysql anggota
$anggota = query_anggota();
$anggotaPerGender = query_anggota("SELECT jeniskelamin, COUNT(jeniskelamin) as total FROM tbanggota
GROUP BY jeniskelamin");

// mysql buku
$tbbuku = query_buku();
$kategori = query_buku("SELECT kategori,COUNT(kategori) as jumlah FROM tbbuku
GROUP BY kategori");
