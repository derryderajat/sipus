<?php

use function PHPSTORM_META\type;

// session_start();
  require_once "config/connect.php";


if( isset($_POST["submit"])){
  // echo tambah($_POST);

    if( tambahBuku($_POST)>0){
      echo "
          <script>
              alert('data berhasil ditambahkan');
              document.location.href = 'index.php?p=buku'
          </script>
      ";
    }else{
      echo "
      <script>
          alert('data Gagal');
          
      </script>
      ";
  }
}



?>

<h2>Daftar Buku</h2>
<form action="" method="POST">
  <div class="input-group mb-3">
    <input type="text" class="form-control" id="keyword" name="keyword" placeholder="Masukkan keyword untuk pencarian" autofocus id="keyword">
  </div>
</form>
<?php if (isset($_SESSION)) : ?>
<?php if ($_SESSION["type"] == "US"):?>
<button type="button" class="btn btn-primary mb-2" data-toggle="modal" data-target="#formModal">Tambah Buku</button>
<?php endif; ?>
<?php endif; ?>

<div class="slider" id="container">
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">No.</th>
        <th scope="col">ID Buku</th>
        <th scope="col">Judul</th>
        <th scope="col">Kategori</th>
        <th scope="col">Pengarang</th>
        <th scope="col">Penerbit</th>
        <th scope="col">Status</th>
        <?php if ($_SESSION["type"] == "US"):?>
        <th scope="col">Opsi</th>
        <?php endif;?>
      </tr>
    </thead>
    <tbody class="slide">
      <?php $i=1;$j=1;?>
      <?php foreach($tbbuku as $buku):?>
      <tr>
        <th scope="row"><?=$i++;?></th>
        <td><?= $buku['idbuku'];?></td>
        <td><?= $buku['judulbuku'];?></td>
        <td><?= $buku['kategori'];?></td>
        <td><?= $buku['pengarang'];?></td>
        <td><?= $buku['penerbit'];?></td>
        <td><?= $buku['statusbuku'];?></td>
        <?php if ($_SESSION["type"] == "US"):?>
        <td>
          <a href="index.php?p=buku-edit&id=<?=$buku['idbuku']?>" class="badge badge-warning"><i
              class="fas fa-edit fa-lg"></i></a>
        </td>
        <?php endif;?>
      </tr>
      <?php endforeach;?>
    </tbody>

  </table>
</div>


<!-- Modal Add Buku-->
<div class="modal fade" id="formModal" tabindex="-1" aria-labelledby="formModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="formModalLabel">Tambah Buku</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="POST">
          <div class="form-group">
            <label for="idbuku">ID Buku</label>
            <input type="text" class="form-control" id="idbuku" name="idbuku" required>
          </div>

          <div class="form-group">
            <label for="judulbuku">Judul Buku</label>
            <input type="text" class="form-control" id="judulbuku" name="judulbuku" required>
          </div>

          <div class="form-group">
            <label for="kategori">Kategori</label>
            <select class="form-control" id="kategori" name="kategori" required>
              <option value="Ilmu Komputer" selected>Ilmu Komputer</option>
              <option value="Karya Sastra">Karya Sastra</option>
              <option value="Ilmu Agama">Ilmu Agama</option>
            </select>
          </div>
          <div class="form-group">
            <label for="pengarang">Pengarang</label>
            <input type="text" class="form-control" id="pengarang" name="pengarang" required>
          </div>
          <div class="form-group">
            <label for="penerbit">Penerbit</label>
            <input type="text" class="form-control" id="penerbit" name="penerbit" required>
          </div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name="submit">Tambah Data</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>

var keyword = document.getElementById('keyword');
var container = document.getElementById('container');

keyword.addEventListener('keyup', function(){
    // object ajax
    var xhr = new XMLHttpRequest();
    
    // check kesiapan ajax
    xhr.onreadystatechange = function(){
      if ( xhr.readyState == 4 && xhr.status == 200){
        container.innerHTML = xhr.responseText;
      }
    }

    // eksekusi ajax
    xhr.open('GET', 'assets/ajax/buku.php?keyword=' + keyword.value, true)
    xhr.send();
})

</script>