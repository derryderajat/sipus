<?php


session_start();
require_once "../config/connect.php";
$_SESSION = [];
session_unset();
session_destroy();
header("Location: " . BASEURL );
exit;

?>