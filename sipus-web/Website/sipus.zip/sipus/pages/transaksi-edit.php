<?php
require_once "config/connect.php";
if( isset($_POST["perpanjang"])){
      if($_POST["tglkembali"]<$_POST["tglpinjam"]){
        echo "
        <script>
            alert('Tanggal kembali mendahului tanggal pinjam');
            
        </script>
        ";
      }else if( perpanjangTransaksi($_POST)>0){
        echo "  
            <script>
                alert('Peminjaman diperpanjang!');
                document.location.href = 'index.php?p=transaksi'
            </script>
        ";
      }else{

        echo "
        <script>
            alert('data Gagal');
            
        </script>
        ";
    }
} else if( isset($_POST["kembalikan"])){
    
    if( berhentiTransaksi($_POST)>0){
      echo "
          <script>
              alert('Buku telah dikembalikan!');
              document.location.href = 'index.php?p=transaksi'
          </script>
      ";
    }else{

      echo "
      <script>
          alert('data Gagal');
          
      </script>
      ";
  }
}

$idtransaksi = $_GET["id"];
$trs = query_transaksi("SELECT * FROM tbtransaksi WHERE idtransaksi = '$idtransaksi'")[0];



?>

<h1>Edit Peminjaman Buku</h1>
<div class="container">
    <form action="" method="POST">
        <div class="form-group">
            <label for="idtransaksi">ID Transaksi</label>
            <input type="text" class="form-control" id="idtransaksi" placeholder="Another input" name="idtransaksi"
                readonly value="<?=$trs["idtransaksi"];?>">
        </div>
        <div class="form-group">
            <label for="idbuku">ID Buku</label>
            <input type="text" class="form-control" id="idbuku" placeholder="Another input" name="idbuku" readonly
                value="<?=$trs["idbuku"];?>">
        </div>

        <div class="form-group">
            <label for="idanggota">ID Anggota</label>
            <input type="text" class="form-control" id="idanggota" placeholder="Another input" name="idanggota" readonly
                value="<?=$trs["idanggota"];?>">
        </div>
        <div class="form-group">
            <label for="formGroupExampleInput3">Tanggal Kembali</label>
            <input type="date" class="form-control" id="formGroupExampleInput3" name="tglkembali" required
                value="<?=$trs["tglkembali"];?>">
        </div>
        <input type="date" class="form-control" id="formGroupExampleInput3" name="tglpinjam" required value="<?=$trs["tglpinjam"];?>" hidden>

        <button type="submit" name="kembalikan" class="btn btn-danger float-left"
            onclick="return confirm('Kembalikan Buku?')">Kembalikan Buku</button>
        <button type="submit" name="perpanjang" class="btn btn-success float-right"
            onclick="return confirm('Perpanjang Peminjaman?')">Perpanjang</button>
    </form>
</div>