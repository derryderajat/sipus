<?php
    // session_start();
    // The require_once keyword is used to embed PHP code
    // from another file. If the file is not found, 
    // a fatal error is thrown and the program stops
    require_once "config/connect.php";

    // If there's no session login but user entering anggota-edit page 
    // user will be thrown at signin page
    if ( !isset($_SESSION["login"])){
        header("Location: " . BASEURL . "/pages/signin.php");
        exit;
    }
    // Getting id anggota
    $idanggota = $_GET["id"];
    // Query to fetch anggota with id
    $anggota = query_anggota("SELECT * FROM tbanggota WHERE idanggota = '$idanggota' ")[0] ;
    
    // Check is POST["edit"] has been created
    if( isset($_POST["edit"])){
        // If there is a single updated data, will display "data anggota berhasil diubah"
        // And will be moved to anggota.php page
        if( ubahAnggota($_POST)>0){
            echo "
                <script>
                    alert('data anggota berhasil diubah');
                    document.location.href = 'index.php?p=anggota'
                </script>
            ";
        }else{
            echo "
            <script>
                alert('data anggota gagal diubah / tidak ada yang diubah');
                
            </script>
            ";
        }
    }else if ( isset($_POST["delete"])){
        //  Check is POST["delete"] has been created
        // If there is a different value will display 'data anggota berhasil dihapus'
        if(hapusAnggota($idanggota)>0){
            echo "
            <script>
                alert('data anggota berhasil dihapus');
                document.location.href = 'index.php'
            </script>";
        }else{
            // If there's a bug for deleting anggota 
            // This code will be proceed
            echo "<script>
                    alert('data anggota gagal dihapus');
                 </script>";
        }
    }
?>
<!-- DISPLAYING ANGGOTA WHO WANT TO BE DELETED OR UPDATED  -->
<h2>Edit Anggota : <?=$anggota['nama']?></h2>
<form action="" method="POST">
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">ID Anggota</th>
            <th scope="col">Nama</th>
            <th scope="col">Jenis Kelamin</th>
            <th scope="col">Alamat</th>
            <th scope="col">Status</th>
        </tr>
    </thead>
        <tbody class="slide">
            <!-- VIEW DATA THAT HAS BEEN STORED IN THE DATABASE  -->
            <tr>
                <td><?= $anggota['idanggota'];?></td>
                <td><?= $anggota['nama'];?></td>
                <td><?= $anggota['jeniskelamin'];?></td>
                <td><?= $anggota['alamat'];?></td>
                <td><?= $anggota['statusanggota'];?></td>
            </tr>
            <tr>
                <td>Update with new data</td>
            </tr>
            <!-- TEMPLATE FOR CHANGING THE VALUES FROM THIS DATA -->
            <!-- NOTE!!! -->
            <!-- NEED CHANGE VALUE AT LEAST ONCE FOR UPDATING THIS DATA -->
            <tr>
                <td><input class="form-control" type="text" name="idanggota" value="<?= $anggota['idanggota'];?>" required></td>
                <td><input class="form-control" type="text" name="nama" value="<?= $anggota['nama'];?>" required>
                </td>
                <td>
                    <div class="form-group">
                        <select class="form-control" id="jeniskelamin" name="jeniskelamin" required>
                            <option value="Pria" selected>Pria</option>
                            <option value="Wanita">Wanita</option>
                        </select>
                    </div>
                </td>
                <td><input class="form-control" type="text" name="alamat" value="<?= $anggota['alamat'];?>" required>
                </td>
                <td>
                    <select class="form-control"  name="statusanggota" required>
                        <option value="Sedang Meminjam" selected>Sedang Meminjam</option>
                        <option value="Tidak Meminjam">Tidak Meminjam</option>
                    </select>
                </td>
            </tr>
        </tbody>
    </table>
    <!-- DELETE BUTTON, AFTER CLICKING THIS BUTTON IT WILL DISPLAY CONFIRMATION MESSAGE FOR DELETING THIS DATA -->
    <button class="btn btn-danger float-right ml-2" type="submit" name="delete" onclick="return confirm('Hapus Data ?')">Hapus Anggota</button>
    <!-- UPDATE BUTTON, AFTER CHANGING THOSE VALUES THEN USER CLICK THIS BUTTON. THEN, DATA WILL BE UPDATED -->
    <button class="btn btn-warning float-right mr-2" type="submit" name="edit">Update Anggota</button>
</form>