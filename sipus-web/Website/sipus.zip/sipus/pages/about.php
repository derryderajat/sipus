<div class="container mt-5 d-flex justify-content-center">
    <div class="card p-4 mt-3">
        <div class="first">
            <h6 class="heading">Data Enthusiast</h6>
            <div class="time d-flex flex-row align-items-center justify-content-between mt-3">

                <div> <span class="font-weight-bold">Love AI/ML/DL</span> </div>
            </div>
        </div>
        <div class="second d-flex flex-row mt-2">
            <div class="image mr-3"> <img src="https://i.ibb.co/VJkDvWj/Whats-App-Image-2020-10-14-at-13-06-47.jpg" class="rounded-circle" width="60" /> </div>
            <div class="">
                <div class="d-flex flex-row mb-1"> <span>@__derryd__</span>
                    <div class="ratings ml-2"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> </div>
                </div>
                <!-- Follow; See Profile -->
                <div> 
                <a href="https://www.instagram.com/__derryd__/" class="btn btn-outline-dark btn-sm px-2">+ follow</a> 
                <a href="https://www.kaggle.com/derryderajat" class="btn btn-outline-dark btn-sm"><i class="fab fa-kaggle"></i> | See Profile</a> 
                <a href="https://trakteer.id/derry-derajat" class="btn btn-outline-dark btn-sm"><i class="fa fa-coffee"></i>| Trakteer Coffee</a> </div>
            </div>
        </div>
        <hr class="line-color">

        <div class="third mt-4"> <a href="https://api.whatsapp.com/send/?phone=6289677816465&text=Hi, nama saya " class="btn btn-success btn-block"><i class="fa fa-paper-plane"></i> Send a Message</a>
        </div>
    </div>
</div>
</div>