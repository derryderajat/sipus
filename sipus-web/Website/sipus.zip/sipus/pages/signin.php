<?php
session_start();
require "../config/connect.php";
$un;
if(isset($_SESSION["login"])){
    
    header("Location: " . BASEURL . "/index.php");
    exit;
}

if ( isset($_POST['register'])){

    if (register($_POST)>0){
        echo "<script>
                alert('User baru berhasil ditambahkan');
              </script>";
    }else{
        // echo "jalan";
        echo mysqli_error($conn);
    }
}
if ( isset($_POST['login'])){
    $username_login = $_POST["username_login"];
    $password_login = $_POST["password_login"];
    
    // ADMIN
    //check username
    $admin_user = mysqli_query($conn, "SELECT * FROM tbuser WHERE username = '$username_login'");

    if( mysqli_num_rows($admin_user) === 1){
        
        //check password
        $row = mysqli_fetch_assoc($admin_user);
        if (password_verify($password_login, $row["password"])){
            
            $_SESSION["login"] = true;
            $tmp = explode(" ", $row["nama"]);
            $_SESSION["user"] = $tmp[0];
            $_SESSION["type"] = substr(($row["iduser"]),0,2);
            
            header("Location: " . BASEURL . "/index.php");
            exit;
        }
    }

    // ANGGOTA 


    $error = true;
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi User</title>
    <link rel="stylesheet" href="../assets/css/styles-signup-signin.css">

</head>

<body>
    <?php if (isset($error)) :?>
        <p style="color:red; font-style:italic;">username or password is wrong!</p>
    <?php endif;?>
    <div class="login-wrap">
        <div class="login-html">
            <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign
                In</label>
            <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>
            <div class="login-form">
                <!-- Sign In -->
                <form action="" method="POST">
                <div class="sign-in-htm">

                    <div class="group">
                        <label for="username" class="label">Username</label>
                        <input id="username" type="text" class="input" name="username_login">
                    </div>
                    <div class="group">
                        <label for="pass" class="label">Password</label>
                        <input id="pass" type="password" class="input" name="password_login">
                    </div>
                    <div class="group">
                        <input id="check" type="checkbox" class="check" checked>
                        <label for="check"><span class="icon"></span> Keep me Signed in</label>
                    </div>
                    <div class="group">
                        <button type="submit" class="button" name="login">SIGN IN</button>
                    </div>
                    <div class="hr"></div>
                    <div class="foot-lnk">
                        <a href="#forgot">Forgot Password?</a>
                    </div>
                </div>
                </form>

                <!-- Sign Up -->
                <form action="" method="POST">
                <div class="sign-up-htm">
                    <!-- iduser -->

                    <!-- nama -->
                    <div class="group">
                        <label for="nama" class="label">Full Name</label>
                        <input id="nama" type="text" class="input" name="nama" required>
                    </div>
                    <!-- username -->
                    <div class="group">
                        <label for="username" class="label">username</label>
                        <input id="username" type="text" class="input" name="username" required>
                    </div>
                    <!-- password -->
                    <div class="group">
                        <label for="password" class="label">Password</label>
                        <input id="password" type="password" class="input" name="password" required>
                    </div>
                    <!-- konfirmasi password:password2 -->
                    <div class="group">
                        <label for="password2" class="label">Repeat Password</label>
                        <input id="password2" type="password" class="input" name="password2" required>
                    </div>
                    <!-- Email Address :email-->
                    <div class="group">
                        <label for="email" class="label">Email Address</label>
                        <input id="email" type="email" class="input" name="email" required>
                    </div>
                    <div class="group">
                        <button type="submit" class="button" name="register">Sign Up</button>
                    </div>
                    <div class="hr"></div>
                    <div class="foot-lnk">
                        <label for="tab-1">Already Member?</a>
                    </div>
                </div>
                <form>
            </div>
        </div>
    </div>
</body>

</html>