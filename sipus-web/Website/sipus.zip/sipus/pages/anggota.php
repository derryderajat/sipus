<?php
    // session_start();
        // The require_once keyword is used to embed PHP code
        // from another file. If the file is not found, 
        // a fatal error is thrown and the program stops
    require_once "config/connect.php";
    
    // If there's no session login but user entering anggota-edit page 
    // user will be thrown at signin page
    if ( !isset($_SESSION["login"])){
        header("Location: " . BASEURL . "/pages/signin.php");
        exit;
    }
    // IF POST["SUBMIT"] IS CREATED
    if( isset($_POST["submit"])){
        // AND THERE'S A DIFFERENT VALUE AFTER INSERTING ANGGOTA
        // WILL DISPLAY "DATA ANGGOTA BERHASIL DITAMBAHKAN"
        if( tambahAnggota($_POST)>0){
            echo "
                <script>
                    alert('data anggota berhasil ditambahkan');
                    document.location.href = 'index.php?p=anggota'
                </script>
            ";
        }else{
            // IF THERE'S A BUG FOR INSERTING  NEW ANGGOTA INTO DATABASE
            echo "
            <script>
                alert('data anggota gagal ditambahkan');
            </script>
            ";
        }
    }
?>
<div class="label-page">
    <h2>Daftar Anggota</h2>
    <!-- LIVE SEARCHING WITH AJAX -->
    <form action="" method="POST">
        <div class="input-group mb-3">
            <input type="text" class="form-control" id="keyword" name="keyword" placeholder="Masukkan keyword untuk pencarian" autofocus id="keyword">
        </div>
    </form>
    <!-- END LIVE SEARCHING -->
    <!-- CHECK SESSION AND USER -->
    <?php if (isset($_SESSION)) : ?>
    <?php if ($_SESSION["type"] == "US"):?>
    <button type="button" class="btn btn-primary mb-2" data-toggle="modal" data-target="#formModal">Tambah
        Anggota</button>
    <?php endif; ?>
    <?php endif; ?>
    <div class="slider" id="container">
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">No.</th>
                    <th scope="col">Id Anggota</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Jenis Kelamin</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Status</th>
                    <?php if ($_SESSION["type"] == "US"):?>
                    <th scope="col">Opsi</th>
                    <?php endif;?>
                </tr>
            </thead>
            <tbody class="slide">
                <?php $i=1;?>
                <?php foreach($anggota as $ag):?>
                <tr>
                    <th scope="row"><?=$i++;?></th>
                    <td><?= $ag['idanggota'];?></td>
                    <td><?= $ag['nama'];?></td>
                    <td><?= $ag['jeniskelamin'];?></td>
                    <td><?= $ag['alamat'];?></td>
                    <td><?= $ag['statusanggota'];?></td>
                    <?php if ($_SESSION["type"] == "US"):?>
                    <td>
                        <a href="index.php?p=anggota-edit&id=<?=$ag['idanggota']?>" class="badge badge-warning"><i
                                class="fas fa-edit fa-lg"></i>
                        </a>
                    </td>
                    <?php endif;?>
                </tr>
                <?php endforeach;?>
            </tbody>

        </table>
    </div>
</div>
<!-- ADDING ANGGOTA WITH MODAL BOX -->
<div class="modal fade" id="formModal" tabindex="-1" aria-labelledby="formModalLabel" aria-hidden="true">
    <!-- MODAL DIALOG -->
    <div class="modal-dialog">
        <!-- MODAL CONTENT -->
        <div class="modal-content">
            <!-- MODAL HEADER -->
            <div class="modal-header">
                <h5 class="modal-title" id="formModalLabel">Tambah Anggota</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <!-- MODAL BODY -->
            <div class="modal-body">
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="nama">Nama Anggota</label>
                        <input type="text" class="form-control" id="nama" name="nama" required>
                    </div>

                    <div class="form-group">
                        <label for="jeniskelamin">Jenis Kelamin</label>
                        <select class="form-control" id="jeniskelamin" name="jeniskelamin" required>
                            <option value="Pria" selected>Pria</option>
                            <option value="Wanita">Wanita</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <input type="text" class="form-control" id="alamat" name="alamat" required>
                    </div>
                    <div class="form-group">
                        <label for="statusanggota">Status Anggota</label>
                        <select class="form-control" id="statusanggota" name="statusanggota" required>
                            <option value="Tidak Meminjam" selected>Tidak Meminjam</option>
                        </select>
                    </div>

            </div>
            <!-- MODAL FOOTER -->
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" name="submit">Tambah Data</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- SCRIPT AJAX FOR LIVE SEARCHING -->
<script>

var keyword = document.getElementById('keyword');
var container = document.getElementById('container');

keyword.addEventListener('keyup', function(){
    // object ajax
    var xhr = new XMLHttpRequest();
    
    // check kesiapan ajax
    xhr.onreadystatechange = function(){
      if ( xhr.readyState == 4 && xhr.status == 200){
        container.innerHTML = xhr.responseText;
      }
    }

    // eksekusi ajax
    xhr.open('GET', 'assets/ajax/anggota.php?keyword=' + keyword.value, true)
    xhr.send();
})

</script>