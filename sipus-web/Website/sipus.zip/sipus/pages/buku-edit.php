<?php
    // session_start();
    require_once "config/connect.php";
    if ( !isset($_SESSION["login"])){
        header("Location: " . BASEURL . "/pages/signin.php");
        exit;
    }

    $idbuku = $_GET["id"];
    $buku = query_buku("SELECT * FROM tbbuku WHERE idbuku = '$idbuku' ")[0];
    if( isset($_POST["edit"])){
        // echo tambah($_POST);
        if( ubahBuku($_POST)>0){
            echo "
                <script>
                    alert('data berhasil diubah');
                    document.location.href = 'index.php?p=buku'
                </script>
            ";
        }else{
            echo "
            <script>
                alert('data gagal diubah');
                
            </script>
            ";
        }
    }else if ( isset($_POST["delete"])){
        if(hapusBuku($idbuku)>0){
            echo "
            <script>
                alert('data berhasil dihapus');
                document.location.href = 'index.php'
            </script>";
        }else{
            
            echo "<script>
                    alert('data gagal dihapus');
                 </script>";
        }
    }
?>

<h2>Edit Buku : <?=$buku['judulbuku']?></h2>
<form action="" method="POST">
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">ID Buku</th>
            <th scope="col">Judul</th>
            <th scope="col">Kategori</th>
            <th scope="col">Pengarang</th>
            <th scope="col">Penerbit</th>
            <th scope="col">Status</th>
        </tr>
    </thead>
        <tbody class="slide">

            <tr>
                <td><?= $buku['idbuku'];?></td>
                <td><?= $buku['judulbuku'];?></td>
                <td><?= $buku['kategori'];?></td>
                <td><?= $buku['pengarang'];?></td>
                <td><?= $buku['penerbit'];?></td>
                <td><?= $buku['statusbuku'];?></td>
            </tr>
            <tr>
                <td>Edit Data Buku</td>
            </tr>
            <tr>
                <td><input class="form-control" type="text" name="idbuku" value="<?= $buku['idbuku'];?>" required></td>
                <td><input class="form-control" type="text" name="judulbuku" value="<?= $buku['judulbuku'];?>" required>
                </td>
                <td>
                    <div class="form-group">
                        <select class="form-control" id="kategori" name="kategori" required>
                            <option value="Ilmu Komputer" selected>Ilmu Komputer</option>
                            <option value="Karya Sastra">Karya Sastra</option>
                            <option value="Ilmu Agama">Ilmu Agama</option>
                        </select>
                    </div>
                </td>
                <td><input class="form-control" type="text" name="pengarang" value="<?= $buku['pengarang'];?>" required>
                </td>
                <td><input class="form-control" type="text" name="penerbit" value="<?= $buku['penerbit'];?>" required>
                </td>
                <td>
                    <select class="form-control"  name="statusbuku" required>
                        <option value="Tersedia" selected>Tersedia</option>
                        <option value="Dipinjam">Dipinjam</option>
                        <option value="Hilang">Hilang</option>
                    </select>
                </td>
            </tr>
        </tbody>
    </table>
    <button class="btn btn-danger float-right ml-2" type="submit" name="delete" onclick="return confirm('Hapus Data ?')">Hapus Data</button>
    <button class="btn btn-warning float-right mr-2" type="submit" name="edit">Update Data</button>
</form>