<?php

require_once "config/connect.php";
if( isset($_POST["addTransaksi"])){
    // echo tambah($_POST);
    //   var_dump($_POST);
      if( tambahTransaksi($_POST)>0){
        echo "
            <script>
                alert('data berhasil ditambahkan');
                document.location.href = 'index.php?p=transaksi'
            </script>
        ";
      }else{

        echo "
        <script>
            alert('data Gagal');
            
        </script>
        ";
    }
  }
?>

<h1>Transaksi Peminjaman Buku</h1>
<form action="" method="POST">
    <div class="container">
        <div class="input-group mb-3">
            <div class="input-group-append">
                <input type="text" class="form-control" id="keyword" name="keyword" placeholder="Cari Anggota" autofocus
                    id="keyword">
            </div>
            <div class="input-group-append">
                <button class="btn btn-outline-secondary" type="button" onclick="copyClipboard()">Proses</button>
            </div>
        </div>
        <div class="input-group" id="container">
            <span class="form-control" id="target"><?= $anggota[0]['idanggota'];?></span>
            <span class="form-control">
                <?= $anggota[0]['nama'];?>
            </span>
        </div>
    </div>
</form>
<div class="container">
    <form action="" method="POST">
        <div class="form-group">
            <label for="idbuku">ID Buku</label>
            <input type="text" class="form-control" id="idbuku" placeholder="Another input" required name="idbuku">
        </div>
        <div class="form-group">
            <label for="idanggota">ID Anggota</label>
            <input type="text" class="form-control" id="idanggota" placeholder="Another input" name="idanggota"
                readonly>
        </div>
        <div class="form-group">
            <label for="formGroupExampleInput3">Tanggal Kembali</label>
            <input type="date" class="form-control" id="formGroupExampleInput3" name="tglkembali" required>
        </div>
        <button type="submit" name="addTransaksi" class="btn btn-success float-right"
            onclick="return confirm('tambahkan transaksi?')">Tambah Transaksi</button>
    </form>
</div>

<script>
    var keyword = document.getElementById('keyword');
    var container = document.getElementById('container');
    var data = document.getElementById('data');
    keyword.addEventListener('keyup', function () {
        // object ajax

        var xhr = new XMLHttpRequest();

        // check kesiapan ajax
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                container.innerHTML = xhr.responseText;
            }
        }

        // eksekusi ajax
        xhr.open('GET', 'assets/ajax/tambah-transaksi.php?keyword=' + keyword.value, true)
        xhr.send();
    })


    function copyClipboard() {
        /* Get the text field */
        document.getElementById('idanggota').value = document.getElementById('target').innerHTML
    }
</script>