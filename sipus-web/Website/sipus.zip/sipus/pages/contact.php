
<div class="container" id="contact">
            <div class="row">
                <div class="col">
                    <h2 class="text-center">Contact</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-header">Contact Us!
                            
                        </div>
                        <div class="card-body">
                            <p class="card-text text-white">Some quick example text to build on the card title and make up the bulk
                                of the card's content.</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            Location
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">My Office</li>
                            <li class="list-group-item">Panggung Rawi</li>
                            <li class="list-group-item">Cilegon</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md mt-3">
                    <form>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama</label>
                            <input type="text" class="form-control" id="#" aria-describedby="emailHelp">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="text" class="form-control" id="#" aria-describedby="emailHelp">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Alamat</label>
                            <input type="text" class="form-control" id="#" aria-describedby="emailHelp">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">pesan</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>