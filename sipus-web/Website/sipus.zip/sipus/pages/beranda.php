<?php

// Data 
function data($table, $x, $y){
    $result =[];
    foreach($table as $ktg){
        $result[] = array("label"=> $ktg[$x], "y"=> $ktg[$y]);
    }
    return $result;
};
$dataKategori = data($kategori, "kategori", "jumlah");
$dataPengunjung = data($anggotaPerGender, "jeniskelamin", "total");
?>

<script>
window.onload = function () { 
var dataKategori = new CanvasJS.Chart("dataKategori", {
	animationEnabled: true,
	theme: "light2", // "light1", "light2", "dark1", "dark2"
	title: {
		text: "Jumlah Buku per Kategori"
	},
	axisY: {
		title: "Jumlah"
	},
	data: [{
		type: "column",
		dataPoints: <?php echo json_encode($dataKategori, JSON_NUMERIC_CHECK); ?>
	}]
});
var dataPengunjung = new CanvasJS.Chart("dataPengunjung", {
	animationEnabled: true,
	theme: "light2", // "light1", "light2", "dark1", "dark2"
	title: {
		text: "Anggota Perpustakaan"
	},
	axisY: {
		title: "Jumlah"
	},
	data: [{
		type: "column",
		dataPoints: <?php echo json_encode($dataPengunjung, JSON_NUMERIC_CHECK); ?>
	}]
});
dataPengunjung.render();
dataKategori.render();
}
</script>
<div class="container mx-auto">
    <div class="row">
        <div class="col-sm mx-1 mb-3">
            <div id="dataKategori" style="height: 370px; width:auto"></div>
        </div>
        <div class="col-sm mx-1">
            <div id="dataPengunjung" style="height: 370px; width:auto"></div>
        </div>    
    </div>
</div>


