<?php
// session_start();
require_once "config/connect.php";
if ( !isset($_SESSION["login"])){
    header("Location: " . BASEURL . "/pages/signin.php");
    exit;
}
?>
<div class="label-page">
    <h2>Daftar User</h2>
    <div class="slider">
        <table class="table">
            <thead class="thead-dark text-justify">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Id User</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Email</th>
                </tr>
            </thead>
            <tbody class="slide">
                <?php $i=1;?>
                <?php foreach($users as $user):?>
                <tr>
                    <th scope="row"><?= $i++; ?></th>
                    <td><?=$user['iduser'];?></td>
                    <td><?=$user['nama'];?></td>
                    <td><?=$user['email'];?></td>
    
                </tr>
                <?php endforeach;?>
            </tbody>
    
        </table>
    </div>
</div>